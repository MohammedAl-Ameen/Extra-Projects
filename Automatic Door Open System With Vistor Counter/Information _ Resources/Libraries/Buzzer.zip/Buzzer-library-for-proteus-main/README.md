# Buzzer-library-for-proteus

This library can be used with any kind of circuit simulation where buzzer is required. This buzzer breakout library is compatible with all version of proteus as well as stable for any environment.

* Clone or download library file from above link, then copy BUZZER.IDX and BUZZER.LIB file, and paste is in Proteus installation folder >> LIBRARY .

* Now restart proteus and open coponents library , then search for "buzzer". here you will find your bewly added buzzer library.
